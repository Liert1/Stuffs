Enabling this option will translate the pose of the model while sneaking to match the player's.
This means that it will be in the same position relative to the pivots.
It is required for helmet-type models to properly position themselves while the player is sneaking.